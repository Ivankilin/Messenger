let ws;

function connect() {
    ws = new WebSocket('ws://localhost:8080');
    
    ws.onmessage = (event) => {
        const message = event.data;
        appendMessage(message, false);
    };

    ws.onclose = () => {
        setTimeout(connect, 1000);
    };
}

function appendMessage(content, sent) {
    const messages = document.getElementById('messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sent ? 'sent' : 'received'}`;
    messageDiv.textContent = content;
    messages.appendChild(messageDiv);
    messages.scrollTop = messages.scrollHeight;
}

function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (message && ws.readyState === WebSocket.OPEN) {
        ws.send(message);
        appendMessage(message, true);
        input.value = '';
    }
}

// Handle Enter key
document.getElementById('messageInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Initial connection
connect();