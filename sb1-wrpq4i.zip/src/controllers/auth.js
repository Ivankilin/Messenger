import jwt from 'jsonwebtoken';
import User from '../models/user.js';
import { EncryptionService } from '../services/encryption.js';

export class AuthController {
  static async register(req, res) {
    try {
      const { username, password } = req.body;
      
      const existingUser = await User.findOne({ username });
      if (existingUser) {
        return res.status(400).json({ error: 'Username already exists' });
      }

      const keyPair = EncryptionService.generateKeyPair();
      
      const user = new User({
        username,
        password,
        publicKey: keyPair.publicKey,
      });

      await user.save();

      const token = jwt.sign(
        { userId: user._id },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.status(201).json({
        token,
        publicKey: keyPair.publicKey,
        secretKey: keyPair.secretKey, // Send this only once during registration
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async login(req, res) {
    try {
      const { username, password } = req.body;
      
      const user = await User.findOne({ username });
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const isValidPassword = await user.comparePassword(password);
      if (!isValidPassword) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      const token = jwt.sign(
        { userId: user._id },
        process.env.JWT_SECRET,
        { expiresIn: '24h' }
      );

      res.json({ token, publicKey: user.publicKey });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}