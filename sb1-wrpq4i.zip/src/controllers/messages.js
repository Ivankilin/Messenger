import Message from '../models/message.js';
import User from '../models/user.js';
import { EncryptionService } from '../services/encryption.js';
import { ZKProofService } from '../services/zkProof.js';

export class MessageController {
  static async sendMessage(req, res) {
    try {
      const { recipientId, content, proof } = req.body;
      const senderId = req.user.id;

      const [sender, recipient] = await Promise.all([
        User.findById(senderId),
        User.findById(recipientId),
      ]);

      if (!recipient) {
        return res.status(404).json({ error: 'Recipient not found' });
      }

      // Verify ZK proof
      const isValidProof = await ZKProofService.verifyProof(
        process.env.VERIFICATION_KEY,
        proof.proof,
        proof.publicSignals
      );

      if (!isValidProof) {
        return res.status(400).json({ error: 'Invalid proof' });
      }

      // Encrypt message
      const encryptedContent = EncryptionService.encryptMessage(
        content,
        recipient.publicKey,
        req.body.senderSecretKey
      );

      const message = new Message({
        sender: senderId,
        recipient: recipientId,
        encryptedContent,
        proof,
      });

      await message.save();

      // Notify recipient through WebSocket if online
      // Implementation depends on your WebSocket setup

      res.status(201).json({ message: 'Message sent successfully' });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  static async getMessages(req, res) {
    try {
      const userId = req.user.id;
      
      const messages = await Message.find({
        recipient: userId,
      })
      .populate('sender', 'username publicKey')
      .sort('-timestamp');

      res.json({ messages });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }
}