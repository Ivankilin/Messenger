import express from 'express';
import { AuthController } from '../controllers/auth.js';
import { MessageController } from '../controllers/messages.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// Auth routes
router.post('/auth/register', AuthController.register);
router.post('/auth/login', AuthController.login);

// Message routes (protected)
router.post('/messages/send', authenticate, MessageController.sendMessage);
router.get('/messages', authenticate, MessageController.getMessages);

export default router;