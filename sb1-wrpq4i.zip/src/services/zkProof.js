import * as snarkjs from 'snarkjs';

export class ZKProofService {
  static async createProof(input, circuitWasmPath, zkeyPath) {
    try {
      const { proof, publicSignals } = await snarkjs.groth16.fullProve(
        input,
        circuitWasmPath,
        zkeyPath
      );
      
      return {
        proof,
        publicSignals,
      };
    } catch (error) {
      throw new Error(`Failed to create proof: ${error.message}`);
    }
  }

  static async verifyProof(verificationKey, proof, publicSignals) {
    try {
      const isValid = await snarkjs.groth16.verify(
        verificationKey,
        publicSignals,
        proof
      );
      
      return isValid;
    } catch (error) {
      throw new Error(`Failed to verify proof: ${error.message}`);
    }
  }
}