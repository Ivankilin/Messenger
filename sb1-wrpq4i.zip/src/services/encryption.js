import { box, randomBytes } from 'tweetnacl';
import { encodeBase64, decodeBase64, encodeUTF8, decodeUTF8 } from 'tweetnacl-util';

export class EncryptionService {
  static generateKeyPair() {
    const keyPair = box.keyPair();
    return {
      publicKey: encodeBase64(keyPair.publicKey),
      secretKey: encodeBase64(keyPair.secretKey),
    };
  }

  static encryptMessage(message, recipientPublicKey, senderSecretKey) {
    const ephemeralKeyPair = box.keyPair();
    const nonce = randomBytes(box.nonceLength);
    
    const encryptedMessage = box(
      decodeUTF8(message),
      nonce,
      decodeBase64(recipientPublicKey),
      decodeBase64(senderSecretKey)
    );

    return {
      encrypted: encodeBase64(encryptedMessage),
      nonce: encodeBase64(nonce),
      ephemeralPublicKey: encodeBase64(ephemeralKeyPair.publicKey),
    };
  }

  static decryptMessage(encryptedData, senderPublicKey, recipientSecretKey) {
    const decrypted = box.open(
      decodeBase64(encryptedData.encrypted),
      decodeBase64(encryptedData.nonce),
      decodeBase64(senderPublicKey),
      decodeBase64(recipientSecretKey)
    );

    if (!decrypted) throw new Error('Failed to decrypt message');
    
    return encodeUTF8(decrypted);
  }
}